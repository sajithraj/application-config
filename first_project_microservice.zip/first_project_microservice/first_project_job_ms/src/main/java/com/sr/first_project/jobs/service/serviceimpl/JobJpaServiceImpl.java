package com.sr.first_project.jobs.service.serviceimpl;

import com.sr.first_project.jobs.clients.CompanyClient;
import com.sr.first_project.jobs.clients.ReviewClient;
import com.sr.first_project.jobs.dto.JobDto;
import com.sr.first_project.jobs.external.Company;
import com.sr.first_project.jobs.external.Review;
import com.sr.first_project.jobs.mapper.JobMapper;
import com.sr.first_project.jobs.model.Job;
import com.sr.first_project.jobs.repository.JobRepository;
import com.sr.first_project.jobs.service.JobJpaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class JobJpaServiceImpl implements JobJpaService {

    private final CompanyClient companyClient;
    private final ReviewClient reviewClient;
    JobRepository jobRepository;
    @Autowired
    RestTemplate restTemplate;

    public JobJpaServiceImpl(JobRepository jobRepository, CompanyClient companyClient, ReviewClient reviewClient) {
        this.jobRepository = jobRepository;
        this.companyClient = companyClient;
        this.reviewClient = reviewClient;
    }

    @Override
    public List<JobDto> findAll() {
        List<Job> jobs = jobRepository.findAll();
//        List<JobDto> jobWithCompanyDtos = new ArrayList<>();
        return jobs.stream().map(this::convertToDto).collect(Collectors.toList());

    }

    private JobDto convertToDto(Job job) {
        Company company = companyClient.getCompany(job.getCompanyId());
        List<Review> reviews = reviewClient.getReviews(job.getCompanyId());
        return JobMapper.MapTjobWithCompanyDto(job, company, reviews);

//        commented since configuration is autowired
//        RestTemplate restTemplate = new RestTemplate();

//        http://localhost:8081/company/
//        Company company = restTemplate.getForObject("http://COMPANY-MICROSERVICE:8081/company/" + job.getCompanyId(), Company.class);

//        ResponseEntity<List<Review>> reviewResponse = restTemplate.exchange(
//                "http://REVIEW-MICROSERVICE:8083/review?companyId=" + job.getCompanyId(),
//                HttpMethod.GET,
//                null,
//                new ParameterizedTypeReference<List<Review>>() {
//                });
//        List<Review> reviews = reviewResponse.getBody();

    }

    @Override
    public void createJob(Job job) {
        jobRepository.save(job);
    }

    @Override
    public JobDto findJob(Long id) {
        Job job = jobRepository.findById(id).orElse(null);
        return convertToDto(job);
    }

    @Override
    public boolean deleteJob(Long id) {
        try {
            Job job = jobRepository.findById(id).orElse(null);
            if (job != null) {
                jobRepository.deleteById(id);
                return true;
            }
            return false;

        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean updateJob(Long id, Job updateJob) {
        Optional<Job> jobOPtional = jobRepository.findById(id);
        if (jobOPtional.isPresent()) {
            Job job = jobOPtional.get();

            job.setTitle(updateJob.getTitle());
            job.setDescription(updateJob.getDescription());
            job.setLocation(updateJob.getLocation());
            job.setMaxSalary(updateJob.getMaxSalary());
            job.setMinSalary(updateJob.getMinSalary());
            jobRepository.save(job);
            return true;
        }
        return false;
    }

}
