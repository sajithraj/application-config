package com.sr.first_project.jobs.mapper;

import com.sr.first_project.jobs.dto.JobDto;
import com.sr.first_project.jobs.external.Company;
import com.sr.first_project.jobs.external.Review;
import com.sr.first_project.jobs.model.Job;

import java.util.List;

public class JobMapper {

    public static JobDto MapTjobWithCompanyDto(Job job, Company company, List<Review> reviews) {

        JobDto jobWithCompanyDto = new JobDto();

        jobWithCompanyDto.setId(job.getId());
        jobWithCompanyDto.setTitle(job.getTitle());
        jobWithCompanyDto.setDescription(job.getDescription());
        jobWithCompanyDto.setLocation(job.getLocation());
        jobWithCompanyDto.setMaxSalary(job.getMaxSalary());
        jobWithCompanyDto.setMinSalary(job.getMinSalary());

        jobWithCompanyDto.setCompany(company);

        jobWithCompanyDto.setReview(reviews);

        return jobWithCompanyDto;
    }
}
