package com.sr.first_project.jobs.service;


import com.sr.first_project.jobs.dto.JobDto;
import com.sr.first_project.jobs.model.Job;

import java.util.List;

public interface JobJpaService {

    List<JobDto> findAll();

    void createJob(Job job);

    JobDto findJob(Long id);

    boolean deleteJob(Long id);

    boolean updateJob(Long id, Job updateJob);

}
