package com.sr.first_project.jobs.clients;

import com.sr.first_project.jobs.external.Review;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "REVIEW-MICROSERVICE")
public interface ReviewClient {

    @GetMapping("/review")
    List<Review> getReviews(@RequestParam("companyId") Long companyId);
}
