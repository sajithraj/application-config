package com.sr.first_project.jobs.controller;


import com.sr.first_project.jobs.dto.JobDto;
import com.sr.first_project.jobs.model.Job;
import com.sr.first_project.jobs.service.JobJpaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/jobs")
public class jobJpaController {

    private final JobJpaService jobJpaService;

    public jobJpaController(JobJpaService jobJpaService) {
        this.jobJpaService = jobJpaService;
    }

    @GetMapping
    public ResponseEntity<List<JobDto>> findAll() {

//        RestTemplate restTemplate = new RestTemplate();
//        Company comp = restTemplate.getForObject("http://localhost:8081/company/1", company.class);
//        System.out.println(comp);
//        System.out.println(comp.getName());

        return new ResponseEntity<>(jobJpaService.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<JobDto> findJob(@PathVariable Long id) {
        JobDto jobWithCompanyDto = jobJpaService.findJob(id);
        if (jobWithCompanyDto != null) {
            return new ResponseEntity<>(jobWithCompanyDto, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping
    public ResponseEntity<String> addJob(@RequestBody Job job) {
        jobJpaService.createJob(job);
        return new ResponseEntity<>("Successfully added", HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateJob(@PathVariable long id, @RequestBody Job updatedJob) {

        boolean updated = jobJpaService.updateJob(id, updatedJob);
        if (updated) {
            return new ResponseEntity<>("UPdated successfully", HttpStatus.OK);
        }
        return new ResponseEntity<>("Not found", HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteJob(@PathVariable long id) {
        boolean deleted = jobJpaService.deleteJob(id);
        if (deleted) {
            return new ResponseEntity<>("Deleted successfully", HttpStatus.OK);
        }
        return new ResponseEntity<>("Not found", HttpStatus.NOT_FOUND);
    }
}
