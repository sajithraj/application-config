package com.sr.first_project.jobs.repository;

import com.sr.first_project.jobs.model.Job;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobRepository extends JpaRepository<Job, Long> {
}
