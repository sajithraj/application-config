package com.sr.first_project.review.service.service_impl;

import com.sr.first_project.review.model.Review;
import com.sr.first_project.review.repository.ReviewRepository;
import com.sr.first_project.review.service.ReviewService;
import org.springframework.stereotype.Service;

import java.security.UnresolvedPermission;
import java.util.List;

@Service
public class ReviewServiceImplementation implements ReviewService {

    private final ReviewRepository reviewRepository;

    public ReviewServiceImplementation(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }


    @Override
    public List<Review> getAllReview(Long companyId) {
        return reviewRepository.findByCompanyId(companyId);
    }

    @Override
    public Review getReviewById(Long reviewId) {
        return reviewRepository.findById(reviewId).orElse(null);
    }

    @Override
    public boolean createReview(Long companyId, Review review) {
        if (companyId != null & review != null) {
            review.setCompanyId(companyId);
            reviewRepository.save(review);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean updateReview(Long reviewId, Review updateReview) {
        Review review = reviewRepository.findById(reviewId).orElse(null);
        if (review != null) {
            review.setTitle(updateReview.getTitle());
            review.setRating(updateReview.getRating());
            review.setDescription(updateReview.getDescription());
            review.setCompanyId(updateReview.getCompanyId());
            reviewRepository.save(updateReview);
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteReview(Long reviewId) {
        try {
            Review review = reviewRepository.findById(reviewId).orElse(null);
            if (review != null && reviewRepository.existsById(reviewId)) {
                reviewRepository.deleteById(reviewId);
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }
}
