package com.sr.first_project.review.service;

import com.sr.first_project.review.model.Review;

import java.util.List;

public interface ReviewService {

    List<Review> getAllReview(Long companyId);
    Review getReviewById(Long reviewId);
    boolean createReview(Long companyId,Review review);
    boolean updateReview(Long reviewId , Review review);
    boolean deleteReview( Long reviewId);

}
