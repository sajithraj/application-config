package com.sr.first_project.company.controller;

import com.sr.first_project.company.Service.CompanyService;
import com.sr.first_project.company.model.Company;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/company")
public class CompanyController {

    private final CompanyService companyService;

    public CompanyController(CompanyService companyService) {
        this.companyService = companyService;
    }


    @GetMapping
    public List<Company> findAll() {
        return companyService.getAllCompany();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Company> getCompanyById(@PathVariable Long id) {
        Company company = companyService.getCompany(id);
        if (company != null) {
            return new ResponseEntity<>(company, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);

    }

    @PostMapping
    public ResponseEntity<String> createCompany(@RequestBody Company company) {
        companyService.createCompany(company);
        return new ResponseEntity<>("Created successfully", HttpStatus.ACCEPTED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateCompanyById(@RequestBody Company company, @PathVariable Long id) {

        boolean is_updated = companyService.updateCompany(id, company);
        if (is_updated) {
            return new ResponseEntity<>("UPdated successfullly", HttpStatus.OK);
        }
        return new ResponseEntity<>("id Not found " + id.toString(), HttpStatus.NOT_FOUND);

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCompanyById(@PathVariable Long id) {
        boolean is_deleted = companyService.deleteCompany(id);
        if (is_deleted) {
            return new ResponseEntity<>("Deteted successfullly", HttpStatus.OK);
        }
        return new ResponseEntity<>("id Not found " + id.toString(), HttpStatus.NOT_FOUND);

    }
}
