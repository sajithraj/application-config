package com.sr.first_project.company.Service.ServiceImpl;

import com.sr.first_project.company.Repository.CompanyRepo;
import com.sr.first_project.company.Service.CompanyService;
import com.sr.first_project.company.model.Company;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CompanyServiceIMp implements CompanyService {

    private final CompanyRepo companyRepo;

    public CompanyServiceIMp(CompanyRepo companyRepo) {
        this.companyRepo = companyRepo;
    }


    @Override
    public List<Company> getAllCompany() {
        return companyRepo.findAll();
    }

    @Override
    public Company getCompany(Long id) {
        return companyRepo.findById(id).orElse(null);
    }

    @Override
    public void createCompany(Company company) {
        companyRepo.save(company);
    }


    @Override
    public boolean updateCompany(Long id, Company updateCompany) {

        Optional<Company> companyOptional = companyRepo.findById(id);

        if (companyOptional.isPresent()) {
            Company company = companyOptional.get();

            company.setName(updateCompany.getName());
            company.setDescription(updateCompany.getDescription());
            companyRepo.save(company);
            return true;
        }
        return false;
    }


    @Override
    public boolean deleteCompany(Long id) {
        try {
            companyRepo.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
