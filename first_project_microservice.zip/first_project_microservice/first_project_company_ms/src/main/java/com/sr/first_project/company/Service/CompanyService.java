package com.sr.first_project.company.Service;

import com.sr.first_project.company.model.Company;

import java.util.List;

public interface CompanyService {

    List<Company> getAllCompany();
    Company getCompany(Long id);
    void createCompany(Company company);
    boolean updateCompany(Long id,Company company);
    boolean deleteCompany(Long id);
}
